class Book {
 String title
 static constraints = {
	title(unique:true)
 }
}
