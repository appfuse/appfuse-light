class BookController {
	def scaffold = Book
}
